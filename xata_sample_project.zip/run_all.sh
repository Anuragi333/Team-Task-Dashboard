#!/usr/bin/env bash
echo "Start backend (open a terminal):"
echo "uvicorn backend.app:app --reload --port 8000"
echo ""
echo "Start Streamlit UI (open another terminal):"
echo "streamlit run ui/streamlit_app.py"
