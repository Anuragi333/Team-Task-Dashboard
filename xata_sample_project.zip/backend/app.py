from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from backend.services.ingestion import Ingestor
from backend.services.retrieval import Retriever
from backend.services.mcp_router import MCPRouter
import uuid, os

app = FastAPI(title="Xata Minimal Backend")

INGESTOR = Ingestor(storage_dir=os.path.join(os.getcwd(), 'backend', 'data'))
RETRIEVER = Retriever(INGESTOR)
MCP = MCPRouter(project_store=INGESTOR)

class IngestReq(BaseModel):
    project_id: str
    text: str
    filename: str | None = None

class AskReq(BaseModel):
    project_id: str
    query: str
    top_k: int | None = 3

@app.post('/projects', summary='Create a demo project (sqlite-backed)')
def create_project(name: str):
    project_id = str(uuid.uuid4())[:8]
    INGESTOR.create_project(project_id, name)
    return {'project_id': project_id, 'name': name}

@app.post('/ingest')
async def ingest(req: IngestReq):
    if not INGESTOR.project_exists(req.project_id):
        raise HTTPException(status_code=404, detail='project not found')
    doc_id = INGESTOR.add_text(req.project_id, req.text, filename=req.filename or 'pasted')
    return {'status':'ok','doc_id':doc_id}

@app.post('/ask')
def ask(req: AskReq):
    if not INGESTOR.project_exists(req.project_id):
        raise HTTPException(status_code=404, detail='project not found')
    contexts = RETRIEVER.retrieve(req.project_id, req.query, top_k=req.top_k or 3)
    answer = RETRIEVER.mock_llm_answer(req.query, contexts)
    return {'answer': answer, 'contexts': contexts}

@app.post('/tools/sql.query')
def sql_query(project_id: str, sql: str):
    if not INGESTOR.project_exists(project_id):
        raise HTTPException(status_code=404, detail='project not found')
    if not sql.strip().lower().startswith('select'):
        raise HTTPException(status_code=400, detail='Only SELECT queries allowed in this demo tool')
    rows = MCP.run_sql(project_id, sql)
    return {'columns': rows['columns'], 'rows': rows['rows']}
