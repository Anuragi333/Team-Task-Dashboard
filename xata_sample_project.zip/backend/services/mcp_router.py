import os, sqlite3

class MCPRouter:
    def __init__(self, project_store):
        self.project_store = project_store

    def project_db_path(self, project_id):
        proj_path = os.path.join(self.project_store.projects_dir, project_id)
        return os.path.join(proj_path, 'data.db')

    def run_sql(self, project_id, sql):
        db = self.project_db_path(project_id)
        if not os.path.exists(db):
            return {'columns': [], 'rows': []}
        conn = sqlite3.connect(db)
        cur = conn.cursor()
        cur.execute(sql)
        cols = [d[0] for d in cur.description] if cur.description else []
        rows = cur.fetchmany(500)
        conn.close()
        return {'columns': cols, 'rows': rows}
