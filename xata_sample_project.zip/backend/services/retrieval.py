import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

class Retriever:
    def __init__(self, ingestor):
        self.ingestor = ingestor

    def retrieve(self, project_id, query, top_k=3):
        store = self.ingestor.vector_store.get(project_id)
        if not store or store.get('matrix') is None:
            return []
        q_vec = store['vectorizer'].transform([query])
        sims = cosine_similarity(q_vec, store['matrix'])[0]
        idxs = np.argsort(-sims)[:top_k]
        results = []
        for i in idxs:
            results.append(store['docs'][i])
        return results

    def mock_llm_answer(self, query, contexts):
        if not contexts:
            return "I don't have any indexed documents for this project yet. Please upload files or ingest text."
        ctx = "\n\n---\n\n".join(contexts)
        answer = f"(Mock LLM) Based on the retrieved context:\n\n{ctx}\n\nQuestion: {query}\n\nShort answer: The agent found {len(contexts)} relevant chunks."
        return answer
