import os, uuid, json, sqlite3
from sklearn.feature_extraction.text import TfidfVectorizer

class Ingestor:
    def __init__(self, storage_dir='backend/data'):
        self.storage_dir = storage_dir
        os.makedirs(self.storage_dir, exist_ok=True)
        self.projects_dir = os.path.join(self.storage_dir, 'projects')
        os.makedirs(self.projects_dir, exist_ok=True)
        self.vector_store = {}

    def create_project(self, project_id, name):
        proj_path = os.path.join(self.projects_dir, project_id)
        os.makedirs(proj_path, exist_ok=True)
        meta = {'project_id': project_id, 'name': name}
        with open(os.path.join(proj_path, 'meta.json'), 'w') as f:
            json.dump(meta, f)
        db_path = os.path.join(proj_path, 'data.db')
        if not os.path.exists(db_path):
            conn = sqlite3.connect(db_path)
            conn.execute('CREATE TABLE demo(id INTEGER PRIMARY KEY, val TEXT)')
            conn.executemany('INSERT INTO demo(val) VALUES(?)', [('row1',), ('row2',), ('row3',)])
            conn.commit()
            conn.close()
        self.vector_store[project_id] = {'docs': [], 'vectorizer': TfidfVectorizer(), 'matrix': None}

    def project_exists(self, project_id):
        return project_id in self.vector_store

    def add_text(self, project_id, text, filename='pasted'):
        pid = str(uuid.uuid4())[:8]
        chunks = [c.strip() for c in text.split('\n') if c.strip()]
        if not chunks:
            chunks = [text]
        entry = {'id': pid, 'filename': filename, 'chunks': chunks}
        proj_path = os.path.join(self.projects_dir, project_id)
        with open(os.path.join(proj_path, f'doc_{pid}.json'), 'w') as f:
            json.dump(entry, f)
        store = self.vector_store[project_id]
        store['docs'].extend(chunks)
        try:
            store['matrix'] = store['vectorizer'].fit_transform(store['docs'])
        except Exception:
            store['matrix'] = None
        return pid

    def list_docs(self, project_id):
        proj_path = os.path.join(self.projects_dir, project_id)
        docs = []
        for p in os.listdir(proj_path):
            if p.startswith('doc_') and p.endswith('.json'):
                with open(os.path.join(proj_path, p)) as f:
                    docs.append(json.load(f))
        return docs
