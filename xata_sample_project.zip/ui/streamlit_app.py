import streamlit as st
import requests, os

BACKEND = os.environ.get('XATA_BACKEND','http://localhost:8000')

st.set_page_config(page_title='Xata Minimal UI', layout='wide')
st.title('Xata-style Agent - Minimal Sample')

st.sidebar.header('Projects')
if 'project_id' not in st.session_state:
    st.session_state.project_id = None
    st.session_state.project_name = None

if st.sidebar.button('Create demo project'):
    resp = requests.post(f"{BACKEND}/projects", params={'name': 'demo_project'})
    data = resp.json()
    st.session_state.project_id = data['project_id']
    st.session_state.project_name = data['name']

st.sidebar.write('Current project:')
st.sidebar.write(st.session_state.project_id or 'None')

st.header('Ingest / Upload')
uploaded = st.file_uploader('Upload a text file (.txt) for ingestion', type=['txt'])
text_input = st.text_area('Or paste text here', height=150)
if st.button('Ingest'):
    if not st.session_state.project_id:
        st.error('Create a project first (sidebar).')
    else:
        if uploaded is not None:
            b = uploaded.read().decode('utf-8')
            payload = {'project_id': st.session_state.project_id, 'text': b, 'filename': uploaded.name}
        else:
            payload = {'project_id': st.session_state.project_id, 'text': text_input, 'filename': 'pasted'}
        resp = requests.post(f"{BACKEND}/ingest", json=payload)
        st.write(resp.json())

st.header('Ask a question')
q = st.text_input('Question about your ingested docs')
if st.button('Ask'):
    if not st.session_state.project_id:
        st.error('Create a project first.')
    else:
        resp = requests.post(f"{BACKEND}/ask", json={'project_id': st.session_state.project_id, 'query': q})
        data = resp.json()
        st.subheader('Answer')
        st.text(data.get('answer'))
        st.subheader('Retrieved contexts')
        for c in data.get('contexts', []):
            st.write('-', c)

st.sidebar.header('MCP Tools (demo)')
if st.sidebar.button('Run demo SQL (SELECT)'):
    if not st.session_state.project_id:
        st.error('Create a project first.')
    else:
        sql = 'SELECT * FROM demo LIMIT 5;'
        resp = requests.post(f"{BACKEND}/tools/sql.query", params={'project_id': st.session_state.project_id, 'sql': sql})
        st.sidebar.write(resp.json())
