Xata-style Agent - Minimal Sample Project
=========================================

What this sample contains:
- backend/: FastAPI app with endpoints /ingest, /ask, /projects and a simple MCP sql.query tool.
  Retrieval is implemented with sklearn's TfidfVectorizer for a lightweight demo (no heavy LLM or vector DB required).
- ui/: Streamlit app that calls the backend to ingest files and ask questions.
- requirements.txt: Python packages needed for the sample.
- run_all.sh: Simple helper to run backend and UI (for dev; run in separate terminals).

Quick start (Windows):
1. python -m venv .venv
2. .venv\Scripts\activate
3. pip install -r requirements.txt
4. Start backend: uvicorn backend.app:app --reload --port 8000
5. In another terminal, start UI: streamlit run ui/streamlit_app.py
6. Open the Streamlit URL in your browser, create a project, upload a text file, ingest, and ask questions.
